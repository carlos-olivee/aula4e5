import cv2

# --- Variáveis globais ---
drawing = False
ix, iy = -1, -1
fx, fy = -1, -1
roi_selected = False

# --- Função de callback do mouse ---
def draw_rectangle(event, x, y, flags, param):
    global ix, iy, fx, fy, drawing, roi_selected

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        ix, iy = x, y

    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing:
            fx, fy = x, y

    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        fx, fy = x, y
        roi_selected = True

# --- Abre o vídeo ---
video = cv2.VideoCapture("escalator.mp4")

ret, frame = video.read()
frame = cv2.resize(frame, (1100, 720))

cv2.namedWindow("Selecione a área de interesse")
cv2.setMouseCallback("Selecione a área de interesse", draw_rectangle)

while True:
    temp = frame.copy()

    # desenha o retângulo conforme o mouse arrasta
    if drawing or roi_selected:
        cv2.rectangle(temp, (ix, iy), (fx, fy), (0, 255, 0), 2)

    cv2.imshow("Selecione a área de interesse", temp)

    key = cv2.waitKey(1) & 0xFF
    if key == 13 and roi_selected:  # ENTER confirma
        break
    elif key == 27:  # ESC cancela
        video.release()
        cv2.destroyAllWindows()
        exit()

# --- Normaliza coordenadas e calcula dimensões ---
x, y = min(ix, fx), min(iy, fy)
w, h = abs(fx - ix), abs(fy - iy)

print(f"\n Área selecionada:")
print(f"x={x}, y={y}, w={w}, h={h}")
print(f"Porcentagem da imagem: {round((w*h)/(1100*720)*100, 2)}%")

# --- Mostra apenas a ROI selecionada ---
roi = frame[y:y+h, x:x+w]
cv2.imshow("Região selecionada (ROI)", roi)

cv2.waitKey(0)
cv2.destroyAllWindows()
video.release()

